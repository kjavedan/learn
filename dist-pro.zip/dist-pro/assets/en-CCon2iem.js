const l="hello",e={hello:l};export{e as default,l as hello};
