const e="你好",l={hello:"你好"};export{l as default,e as hello};
